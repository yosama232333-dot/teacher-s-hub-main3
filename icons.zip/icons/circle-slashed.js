/**
 * @license lucide-react v0.575.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */

export { default } from './circle-slash-2.js';
//# sourceMappingURL=circle-slashed.js.map
