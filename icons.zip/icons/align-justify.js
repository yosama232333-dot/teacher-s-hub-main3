/**
 * @license lucide-react v0.575.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */

export { default } from './text-align-justify.js';
//# sourceMappingURL=align-justify.js.map
