/**
 * @license lucide-react v0.575.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createLucideIcon from '../createLucideIcon.js';

const __iconNode = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M12 6v6l-2-4", key: "ns39ag" }]
];
const Clock11 = createLucideIcon("clock-11", __iconNode);

export { __iconNode, Clock11 as default };
//# sourceMappingURL=clock-11.js.map
